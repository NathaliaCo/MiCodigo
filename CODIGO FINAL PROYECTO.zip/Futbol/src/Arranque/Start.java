package Arranque;


import Gestion.gestorVariable;

public class Start {

    public static void main(String[] args) throws InterruptedException {
        gestorVariable gestor = new gestorVariable();
        gestor.iniciar();
    }

}